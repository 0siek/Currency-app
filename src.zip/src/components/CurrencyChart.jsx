import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import "../App.css";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const ALL_CURRENCIES = ["EUR", "USD", "GBP", "CHF", "PLN", "CAD", "JPY"];

// Predefiniowane zakresy do wyboru
// Każda wartość odpowiada ilości dni wstecz od dziś.
const PREDEFINED_RANGES = [
  { label: "7 dni", value: 7 },
  { label: "30 dni", value: 30 },
  { label: "3 miesiące", value: 90 },
  { label: "6 miesięcy", value: 180 },
  { label: "1 rok", value: 365 },
  { label: "2 lata", value: 730 },
  { label: "3 lata", value: 1095 },
  { label: "Własny przedział", value: "custom" },
];

function CurrencyChart({ base }) {
  const [chartCurrency, setChartCurrency] = useState("USD");
  const [chartData, setChartData] = useState(null);

  // Stan do zarządzania zakresem
  const [selectedRange, setSelectedRange] = useState(7);
  const [customRangeDays, setCustomRangeDays] = useState(30);
  const [customRangeType, setCustomRangeType] = useState("days");

  const formatDate = (date) => date.toISOString().split("T")[0];

  const getDateRange = () => {
    const endDate = new Date();
    const startDate = new Date();

    let daysBack;
    if (selectedRange === "custom") {
      if (customRangeType === "days") {
        daysBack = customRangeDays;
      } else {
        daysBack = customRangeDays * 365;
      }
    } else {
      daysBack = selectedRange;
    }

    startDate.setDate(endDate.getDate() - daysBack);
    return { start: formatDate(startDate), end: formatDate(endDate) };
  };

  useEffect(() => {
    const { start, end } = getDateRange();

    fetch(
      `https://api.frankfurter.app/${start}..${end}?from=${base}&to=${chartCurrency}`
    )
      .then((res) => res.json())
      .then((data) => {
        if (!data.rates) return;
        const labels = Object.keys(data.rates).sort();
        const values = labels.map((date) => data.rates[date][chartCurrency]);

        setChartData({
          labels,
          datasets: [
            {
              label: `Kurs ${base}/${chartCurrency}`,
              data: values,
              borderColor: "rgba(75,192,192,1)",
              backgroundColor: "rgba(75,192,192,0.2)",
            },
          ],
        });
      });
  }, [base, chartCurrency, selectedRange, customRangeDays, customRangeType]);

  return (
    <div className="container">
      <h2>Wykres kursów z wybranego przedziału czasowego</h2>

      {/* Wybór waluty */}
      <div>
        <label>
          Wybierz walutę:
          <select
            value={chartCurrency}
            onChange={(e) => setChartCurrency(e.target.value)}
          >
            {ALL_CURRENCIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
      </div>

      {/* Wybór zakresu */}
      <div>
        <label>
          Wybierz zakres:
          <select
            value={selectedRange}
            onChange={(e) => setSelectedRange(e.target.value)}
          >
            {PREDEFINED_RANGES.map((range) => (
              <option key={range.value} value={range.value}>
                {range.label}
              </option>
            ))}
          </select>
        </label>

        {selectedRange === "custom" && (
          <div>
            <label>
              Podaj wartość:
              <input
                type="number"
                min="1"
                value={customRangeDays}
                onChange={(e) => setCustomRangeDays(Number(e.target.value))}
              />
            </label>
            <label>
              Jednostka:
              <select
                value={customRangeType}
                onChange={(e) => setCustomRangeType(e.target.value)}
              >
                <option value="days">dni</option>
                <option value="years">lata</option>
              </select>
            </label>
          </div>
        )}
      </div>

      {!chartData ? <p>Ładowanie wykresu...</p> : <Line data={chartData} />}
    </div>
  );
}

export default CurrencyChart;
