import React from "react";
import "../App.css";
function CurrencyTable({ base, mainRates }) {
  return (
    <div className="container">
      <h2>Kursy głównych walut bazując na: {base}</h2>
      <table style={{ borderCollapse: "collapse", width: "300px" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Waluta</th>
            <th style={{ border: "1px solid #ccc", padding: "8px" }}>Kurs</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(mainRates).map(([currency, rate]) => (
            <tr key={currency}>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>
                {currency}
              </td>
              <td style={{ border: "1px solid #ccc", padding: "8px" }}>
                {rate}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CurrencyTable;
