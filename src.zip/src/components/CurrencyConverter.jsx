import React, { useState, useEffect } from "react";
import "../App.css";
const ALL_CURRENCIES = ["EUR", "USD", "GBP", "CHF", "PLN", "CAD", "JPY"];

function CurrencyConverter({ base, onBaseChange, onCurrencySelect }) {
  const [amount, setAmount] = useState(1);
  const [target, setTarget] = useState("USD");
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (amount > 0 && base && target && base !== target) {
      fetch(
        `https://api.frankfurter.app/latest?amount=${amount}&from=${base}&to=${target}`
      )
        .then((res) => res.json())
        .then((data) => {
          setResult(data.rates[target]);
        });
    }
  }, [amount, base, target]);

  const handleConvert = (e) => {
    e.preventDefault();
  };

  return (
    <div className="container">
      <h2>Kalkulator</h2>
      <form
        onSubmit={handleConvert}
        style={{ display: "flex", gap: "10px", alignItems: "center" }}
      >
        <label>
          Kwota:
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min="0"
            style={{ marginLeft: "5px" }}
          />
        </label>
        <label>
          Z:
          <select
            value={base}
            onChange={(e) => onBaseChange(e.target.value)}
            style={{ marginLeft: "5px" }}
          >
            {ALL_CURRENCIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
        <label>
          Na:
          <select
            value={target}
            onChange={(e) => {
              setTarget(e.target.value);
              onCurrencySelect(e.target.value);
            }}
            style={{ marginLeft: "5px" }}
          >
            {ALL_CURRENCIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>
      </form>
      {result && (
        <div style={{ marginTop: "10px" }}>
          {amount} {base} = {result} {target}
        </div>
      )}
    </div>
  );
}

export default CurrencyConverter;
